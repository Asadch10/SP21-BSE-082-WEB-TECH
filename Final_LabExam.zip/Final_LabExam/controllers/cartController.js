const Cart = require('../models/Cart');
const Product = require('../models/Product');

// Get cart for current user
exports.getCart = async (req, res) => {
    try {
        let cart = await Cart.findOne({ user: req.session.user.id }).populate('items.product');
        res.render('cart/view', {
            title: 'Shopping Cart',
            cart: cart || { items: [], total: 0 }
        });
    } catch (error) {
        console.error('Error fetching cart:', error);
        res.status(500).send('Error loading cart');
    }
};

// Add item to cart
exports.addToCart = async (req, res) => {
    try {
        const { productId, quantity = 1, size } = req.body;
        const product = await Product.findById(productId);
        
        if (!product) {
            return res.status(404).json({ error: 'Product not found' });
        }

        if (!product.sizes.includes(size)) {
            return res.status(400).json({ error: 'Invalid size selected' });
        }

        let cart = await Cart.findOne({ user: req.session.user.id });
        
        if (!cart) {
            cart = new Cart({
                user: req.session.user.id,
                items: [],
                total: 0
            });
        }

        // Look for item with same product AND size
        const existingItem = cart.items.find(item => 
            item.product.toString() === productId && item.size === size
        );

        if (existingItem) {
            existingItem.quantity += parseInt(quantity);
        } else {
            cart.items.push({
                product: productId,
                size: size,
                quantity: parseInt(quantity)
            });
        }

        // Recalculate total
        cart.total = await calculateTotal(cart.items);
        await cart.save();

        res.redirect('/cart');
    } catch (error) {
        console.error('Error adding to cart:', error);
        res.status(500).json({ error: 'Error adding item to cart' });
    }
};

// Update cart item quantity
exports.updateCartItem = async (req, res) => {
    try {
        const { productId, quantity, size } = req.body;
        let cart = await Cart.findOne({ user: req.session.user.id });

        if (!cart) {
            return res.status(404).json({ error: 'Cart not found' });
        }

        const itemIndex = cart.items.findIndex(item => 
            item.product.toString() === productId && item.size === size
        );

        if (itemIndex > -1) {
            if (quantity <= 0) {
                cart.items.splice(itemIndex, 1);
            } else {
                cart.items[itemIndex].quantity = quantity;
            }
            cart.total = await calculateTotal(cart.items);
            await cart.save();
        }

        res.redirect('/cart');
    } catch (error) {
        console.error('Error updating cart:', error);
        res.status(500).json({ error: 'Error updating cart' });
    }
};

// Remove item from cart
exports.removeFromCart = async (req, res) => {
    try {
        const { productId, size } = req.params;
        let cart = await Cart.findOne({ user: req.session.user.id });

        if (!cart) {
            return res.status(404).json({ error: 'Cart not found' });
        }

        cart.items = cart.items.filter(item => 
            !(item.product.toString() === productId && item.size === size)
        );
        
        cart.total = await calculateTotal(cart.items);
        await cart.save();

        res.redirect('/cart');
    } catch (error) {
        console.error('Error removing from cart:', error);
        res.status(500).json({ error: 'Error removing item from cart' });
    }
};

// Helper function to calculate cart total
async function calculateTotal(items) {
    let total = 0;
    for (const item of items) {
        const product = await Product.findById(item.product);
        if (product) {
            total += product.price * item.quantity;
        }
    }
    return total;
}