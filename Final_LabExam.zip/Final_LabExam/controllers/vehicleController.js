const Vehicle = require("../models/Vehicle");

// Sample vehicles data
const sampleVehicles = [
  {
    name: "BMW X5",
    brand: "BMW",
    price: 65000,
    type: "SUV",
    image:
      "https://images.unsplash.com/photo-1555215695-3004980ad54e?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Toyota Camry",
    brand: "Toyota",
    price: 28000,
    type: "sedan",
    image:
      "https://images.unsplash.com/photo-1621007947382-bb3c3994e3fb?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Ford F-150",
    brand: "Ford",
    price: 45000,
    type: "truck",
    image:
      "https://images.unsplash.com/photo-1549927681-6a5cbe3b1d83?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Mercedes-Benz C-Class",
    brand: "Mercedes-Benz",
    price: 42000,
    type: "sedan",
    image:
      "https://images.unsplash.com/photo-1563720223185-11003d516935?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
  },
  {
    name: "Honda Civic",
    brand: "Honda",
    price: 25000,
    type: "hatchback",
    image:
      "https://images.unsplash.com/photo-1606664515524-ed2f786a0bd6?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80",
  },
];

// Initialize database with sample vehicles
async function initializeVehicles() {
  try {
    const count = await Vehicle.countDocuments();
    if (count === 0) {
      await Vehicle.insertMany(sampleVehicles);
      console.log("Sample vehicles initialized");
    }
  } catch (error) {
    console.error("Error initializing vehicles:", error);
  }
}

// Call initialization on module load
initializeVehicles();

exports.getAllVehicles = async (req, res) => {
  try {
    const { type } = req.query;
    const query = type ? { type: type.toLowerCase() } : {};

    const vehicles = await Vehicle.find(query);
    res.render("vehicles/list", {
      title: type
        ? `${type.charAt(0).toUpperCase() + type.slice(1)}s`
        : "Our Vehicles",
      vehicles: vehicles,
      currentType: type || "",
    });
  } catch (error) {
    console.error("Error fetching vehicles:", error);
    res.status(500).render("vehicles/list", {
      title: "Our Vehicles",
      vehicles: [],
      currentType: "",
      error: "Failed to load vehicles",
    });
  }
};

exports.getVehicleById = async (req, res) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    if (!vehicle) {
      return res.status(404).send("Vehicle not found");
    }
    res.render("vehicle-detail", {
      title: vehicle.name,
      vehicle: vehicle,
    });
  } catch (error) {
    console.error("Error fetching vehicle:", error);
    res.status(500).send("Error loading vehicle");
  }
};

// Admin CRUD Operations
exports.getAdminVehicles = async (req, res) => {
  try {
    const vehicles = await Vehicle.find();
    // Explicitly set layout
    res.locals.layout = "layouts/auth";
    res.render("admin/vehicles", {
      title: "Vehicle Management",
      vehicles,
      layout: "layouts/auth",
    });
  } catch (error) {
    res.status(500).render("error", {
      title: "Error",
      message: "Error fetching vehicles",
      layout: "layouts/auth",
    });
  }
};

exports.getAddVehicleForm = (req, res) => {
  res.locals.layout = "layouts/auth";
  res.render("admin/vehicle-form", {
    vehicle: {},
    action: "/admin/vehicles",
    title: "Add Vehicle",
    layout: "layouts/auth",
  });
};

exports.createVehicle = async (req, res) => {
  try {
    const { name, brand, price, type } = req.body;
    const vehicleData = { name, brand, price, type };

    if (req.file) {
      vehicleData.image = "/images/" + req.file.filename;
    }

    await Vehicle.create(vehicleData);
    res.redirect("/admin/vehicles");
  } catch (error) {
    console.error("Error creating vehicle:", error);
    res.status(500).render("error", {
      title: "Error",
      message: "Error creating vehicle",
      layout: "layouts/main",
    });
  }
};

exports.getEditVehicleForm = async (req, res) => {
  try {
    const vehicle = await Vehicle.findById(req.params.id);
    if (!vehicle) {
      return res.status(404).render("error", {
        title: "Error",
        message: "Vehicle not found",
        layout: "layouts/auth",
      });
    }
    res.locals.layout = "layouts/auth";
    res.render("admin/vehicle-form", {
      vehicle,
      action: `/admin/vehicles/${vehicle._id}?_method=PUT`,
      title: "Edit Vehicle",
      layout: "layouts/auth",
    });
  } catch (error) {
    res.status(500).render("error", {
      title: "Error",
      message: "Error fetching vehicle",
      layout: "layouts/auth",
    });
  }
};

exports.updateVehicle = async (req, res) => {
  try {
    const { name, brand, price, type } = req.body;
    const updateData = { name, brand, price, type };

    if (req.file) {
      updateData.image = "/images/" + req.file.filename;
    }

    await Vehicle.findByIdAndUpdate(req.params.id, updateData);
    res.redirect("/admin/vehicles");
  } catch (error) {
    console.error("Error updating vehicle:", error);
    res.status(500).render("error", {
      title: "Error",
      message: "Error updating vehicle",
      layout: "layouts/main",
    });
  }
};

exports.deleteVehicle = async (req, res) => {
  try {
    await Vehicle.findByIdAndDelete(req.params.id);
    res.redirect("/admin/vehicles");
  } catch (error) {
    console.error("Error deleting vehicle:", error);
    res.status(500).render("error", {
      title: "Error",
      message: "Error deleting vehicle",
      layout: "layouts/main",
    });
  }
};
