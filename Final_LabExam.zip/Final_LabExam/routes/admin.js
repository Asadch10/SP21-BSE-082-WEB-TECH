const express = require("express");
const router = express.Router();
const { isAuthenticated } = require("../middleware/auth");
const { isAdmin } = require("../middleware/admin");
const Product = require("../models/Product");
const Order = require("../models/Order");
const vehicleController = require("../controllers/vehicleController");
const upload = require("../config/multer");

// Apply middleware to all admin routes
router.use(isAuthenticated);
router.use(isAdmin);

// Product Management Routes
router.get("/products", async (req, res) => {
  try {
    const products = await Product.find();
    res.render("admin/products", {
      products,
      layout: "layouts/auth",
    });
  } catch (error) {
    res.status(500).render("error", {
      message: "Error fetching products",
      layout: "layouts/main",
    });
  }
});

router.get("/products/add", (req, res) => {
  res.render("admin/product-form", {
    product: {},
    action: "/admin/products",
    title: "Add Product",
    layout: "layouts/auth",
  });
});

router.post("/products", async (req, res) => {
  try {
    const { title, description, price, imageUrl } = req.body;
    await Product.create({ title, description, price, imageUrl });
    res.redirect("/admin/products");
  } catch (error) {
    res.status(500).render("error", {
      message: "Error creating product",
      layout: "layouts/main",
    });
  }
});

router.get("/products/:id/edit", async (req, res) => {
  try {
    const product = await Product.findById(req.params.id);
    res.render("admin/product-form", {
      product,
      action: `/admin/products/${product._id}?_method=PUT`,
      title: "Edit Product",
      layout: "layouts/auth",
    });
  } catch (error) {
    res.status(500).render("error", {
      message: "Error fetching product",
      layout: "layouts/main",
    });
  }
});

router.put("/products/:id", async (req, res) => {
  try {
    const { title, description, price, imageUrl } = req.body;
    await Product.findByIdAndUpdate(req.params.id, {
      title,
      description,
      price,
      imageUrl,
    });
    res.redirect("/admin/products");
  } catch (error) {
    res.status(500).render("error", {
      message: "Error updating product",
      layout: "layouts/main",
    });
  }
});

router.delete("/products/:id", async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.redirect("/admin/products");
  } catch (error) {
    res.status(500).render("error", {
      message: "Error deleting product",
      layout: "layouts/main",
    });
  }
});

// Order Management Routes
router.get("/orders", async (req, res) => {
  try {
    const orders = await Order.find().populate("user", "name email");
    res.render("admin/orders", {
      orders,
      layout: "layouts/auth",
    });
  } catch (error) {
    res.status(500).render("error", {
      message: "Error fetching orders",
      layout: "layouts/main",
    });
  }
});

router.put("/orders/:id/status", async (req, res) => {
  try {
    const { status } = req.body;
    await Order.findByIdAndUpdate(req.params.id, { status });
    res.redirect("/admin/orders");
  } catch (error) {
    res.status(500).render("error", {
      message: "Error updating order status",
      layout: "layouts/main",
    });
  }
});

// Vehicle Management Routes
router.get("/vehicles", vehicleController.getAdminVehicles);
router.get("/vehicles/add", vehicleController.getAddVehicleForm);
router.post(
  "/vehicles",
  upload.single("image"),
  vehicleController.createVehicle
);
router.get("/vehicles/:id/edit", vehicleController.getEditVehicleForm);
router.put(
  "/vehicles/:id",
  upload.single("image"),
  vehicleController.updateVehicle
);
router.delete("/vehicles/:id", vehicleController.deleteVehicle);

module.exports = router;
