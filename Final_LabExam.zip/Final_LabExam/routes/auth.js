const express = require('express');
const router = express.Router();
const authController = require('../controllers/authController');
const { isGuest, isAuthenticated } = require('../middleware/auth');

// Base route should show login
router.get('/', isGuest, (req, res) => {
    res.redirect('/auth/login');
});

// Login routes
router.get('/login', isGuest, authController.getLogin);
router.post('/login', isGuest, authController.postLogin);

// Register routes
router.get('/register', isGuest, authController.getRegister);
router.post('/register', isGuest, authController.postRegister);

// Dashboard route
router.get('/dashboard', isAuthenticated, authController.getDashboard);

// Logout route
router.get('/logout', isAuthenticated, authController.logout);

module.exports = router;