const express = require('express');
const router = express.Router();
const { isAuthenticated } = require('../middleware/auth');
const Order = require('../models/Order');

// Get user's orders
router.get('/', isAuthenticated, async (req, res) => {
    try {
        const orders = await Order.find({ user: req.session.user.id })
            .populate('items.product')
            .sort({ createdAt: -1 });

        res.render('orders/my-orders', {
            title: 'My Orders',
            orders: orders
        });
    } catch (error) {
        console.error(error);
        res.status(500).render('error', { 
            message: 'Error fetching orders',
            error: error
        });
    }
});

module.exports = router;
