const mongoose = require('mongoose');
require('dotenv').config();
const User = require('../models/User');

const makeUserAdmin = async (email) => {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        const user = await User.findOneAndUpdate(
            { email: email.toLowerCase() },
            { isAdmin: true },
            { new: true }
        );
        
        if (user) {
            console.log(`User ${email} is now an admin`);
        } else {
            console.log(`User ${email} not found`);
        }
    } catch (error) {
        console.error('Error:', error);
    }
    mongoose.connection.close();
};

// Get email from command line argument
const email = process.argv[2];
if (!email) {
    console.log('Please provide an email address');
    process.exit(1);
}

makeUserAdmin(email);
