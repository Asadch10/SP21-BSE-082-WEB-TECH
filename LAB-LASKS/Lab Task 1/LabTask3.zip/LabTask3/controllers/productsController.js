const Product = require('../models/Product');

// Sample products data
const sampleProducts = [
    {
        name: 'Classic Cotton T-Shirt',
        price: 29.99,
        description: 'Premium cotton t-shirt with a comfortable fit and classic design.',
        image: 'https://images-cdn.ubuy.co.in/64635d08ef7bfe40fa2c12a4-essentials-t-shirt.jpg',
        sizes: ['S', 'M', 'L', 'XL'],
        category: 'shirts'
    },
    {
        name: 'Slim Fit Jeans',
        price: 59.99,
        description: 'Modern slim fit jeans in premium denim with stretch comfort.',
        image: 'https://xcdn.next.co.uk/common/items/default/default/itemimages/3_4Ratio/product/lge/983902s.jpg?im=Resize,width=750',
        sizes: ['S', 'M', 'L', 'XL'],
        category: 'pants'
    },
    {
        name: 'Leather Bomber Jacket',
        price: 149.99,
        description: 'Classic leather bomber jacket with modern styling.',
        image: 'https://www.angeljackets.com/eu/product_images/l/994/brown_distressed_leather_bomber__94825_zoom.webp',
        sizes: ['M', 'L', 'XL'],
        category: 'jackets'
    },
    {
        name: 'Oxford Button-Down Shirt',
        price: 45.99,
        description: 'Timeless Oxford shirt in pure cotton with button-down collar.',
        image: 'https://kingessentials.com/cdn/shop/products/KM111080032_B022T_P1.jpg?v=1655905069&width=1946',
        sizes: ['S', 'M', 'L', 'XL'],
        category: 'shirts'
    },
    {
        name: 'Chino Pants',
        price: 49.99,
        description: 'Classic chino pants in comfortable stretch cotton.',
        image: 'https://images.unsplash.com/photo-1473966968600-fa801b869a1a?ixlib=rb-1.2.1',
        sizes: ['S', 'M', 'L', 'XL'],
        category: 'pants'
    },
    {
        name: 'Denim Jacket',
        price: 79.99,
        description: 'Classic denim jacket with modern fit and vintage wash.',
        image: 'https://images.unsplash.com/photo-1495105787522-5334e3ffa0ef?ixlib=rb-1.2.1',
        sizes: ['S', 'M', 'L', 'XL'],
        category: 'jackets'
    },
    {
        name: 'Polo Shirt',
        price: 34.99,
        description: 'Classic polo shirt in breathable pique cotton.',
        image: 'https://images.unsplash.com/photo-1585856015177-a8309e0d1b3a?ixlib=rb-1.2.1',
        sizes: ['S', 'M', 'L', 'XL'],
        category: 'shirts'
    },
    {
        name: 'Cargo Pants',
        price: 54.99,
        description: 'Functional cargo pants with multiple pockets.',
        image: 'https://images.unsplash.com/photo-1517438322307-e67111335449?ixlib=rb-1.2.1',
        sizes: ['S', 'M', 'L', 'XL'],
        category: 'pants'
    },
    {
        name: 'Hooded Sweatshirt',
        price: 44.99,
        description: 'Comfortable hooded sweatshirt in soft cotton blend.',
        image: 'https://images.unsplash.com/photo-1556821840-3a63f95609a7?ixlib=rb-1.2.1',
        sizes: ['S', 'M', 'L', 'XL'],
        category: 'shirts'
    },
    {
        name: 'Wool Blend Coat',
        price: 199.99,
        description: 'Elegant wool blend coat for cold weather.',
        image: 'https://images.unsplash.com/photo-1539533018447-63fcce2678e3?ixlib=rb-1.2.1',
        sizes: ['M', 'L', 'XL'],
        category: 'jackets'
    }
];

// Initialize database with sample products
async function initializeProducts() {
    try {
        const count = await Product.countDocuments();
        if (count === 0) {
            await Product.insertMany(sampleProducts);
            console.log('Sample products initialized');
        }
    } catch (error) {
        console.error('Error initializing products:', error);
    }
}

// Call initialization on module load
initializeProducts();

exports.getAllProducts = async (req, res) => {
    try {
        const { category } = req.query;
        const query = category ? { category: category.toLowerCase() } : {};
        
        const products = await Product.find(query);
        res.render('products/list', {
            title: category ? `${category.charAt(0).toUpperCase() + category.slice(1)}` : 'Our Collection',
            products: products,
            currentCategory: category || ''
        });
    } catch (error) {
        console.error('Error fetching products:', error);
        res.status(500).render('products/list', {
            title: 'Our Collection',
            products: [],
            currentCategory: '',
            error: 'Failed to load products'
        });
    }
};

exports.getProductById = async (req, res) => {
    try {
        const product = await Product.findById(req.params.id);
        if (!product) {
            return res.status(404).send('Product not found');
        }
        res.render('product-detail', {
            title: product.name,
            product: product
        });
    } catch (error) {
        console.error('Error fetching product:', error);
        res.status(500).send('Error loading product');
    }
};