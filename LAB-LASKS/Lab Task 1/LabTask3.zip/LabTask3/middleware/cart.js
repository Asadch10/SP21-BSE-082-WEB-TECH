const Cart = require('../models/Cart');

exports.cartCounter = async (req, res, next) => {
    if (req.session && req.session.user) {
        try {
            const cart = await Cart.findOne({ user: req.session.user.id });
            if (cart) {
                res.locals.cartCount = cart.items.reduce((total, item) => total + item.quantity, 0);
            } else {
                res.locals.cartCount = 0;
            }
        } catch (error) {
            console.error('Error fetching cart count:', error);
            res.locals.cartCount = 0;
        }
    } else {
        res.locals.cartCount = 0;
    }
    next();
};