const bcrypt = require('bcryptjs');
const User = require('../models/User');

exports.getLogin = (req, res) => {
    res.render('auth/login', { 
        title: 'Login',
        layout: 'layouts/auth'
    });
};

exports.getRegister = (req, res) => {
    res.render('auth/register', { 
        title: 'Register',
        layout: 'layouts/auth'
    });
};

exports.getDashboard = async (req, res) => {
    if (!req.session.user) {
        return res.redirect('/auth/login');
    }
    
    const user = await User.findById(req.session.user.id);
    res.render('auth/dashboard', {
        title: 'Dashboard',
        user: user,
        layout: 'layouts/main'
    });
};

exports.postLogin = async (req, res) => {
    const { email, password } = req.body;
    
    try {
        const user = await User.findOne({ email });
        if (!user) {
            return res.render('auth/login', {
                title: 'Login',
                layout: 'layouts/auth',
                error: 'Invalid email or password'
            });
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.render('auth/login', {
                title: 'Login',
                layout: 'layouts/auth',
                error: 'Invalid email or password'
            });
        }

        // Set user session
        req.session.user = {
            id: user._id,
            name: user.name,
            email: user.email
        };

        res.redirect('/products');
    } catch (error) {
        console.error('Login error:', error);
        res.render('auth/login', {
            title: 'Login',
            layout: 'layouts/auth',
            error: 'An error occurred during login'
        });
    }
};

exports.postRegister = async (req, res) => {
    const { name, email, password, confirmPassword } = req.body;

    try {
        // Validate password match
        if (password !== confirmPassword) {
            return res.render('auth/register', {
                title: 'Register',
                layout: 'layouts/auth',
                error: 'Passwords do not match'
            });
        }

        // Check if user exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.render('auth/register', {
                title: 'Register',
                layout: 'layouts/auth',
                error: 'Email already registered'
            });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Create new user
        const user = new User({
            name,
            email,
            password: hashedPassword
        });

        await user.save();
        res.redirect('/auth/login');
    } catch (error) {
        console.error('Registration error:', error);
        res.render('auth/register', {
            title: 'Register',
            layout: 'layouts/auth',
            error: 'An error occurred during registration'
        });
    }
};

exports.logout = (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
        }
        res.redirect('/auth/login');
    });
};