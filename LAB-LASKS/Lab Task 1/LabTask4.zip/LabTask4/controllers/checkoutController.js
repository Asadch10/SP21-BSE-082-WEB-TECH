const Cart = require('../models/Cart');
const Order = require('../models/Order');

exports.getCheckout = async (req, res) => {
    try {
        const cart = await Cart.findOne({ user: req.session.user.id }).populate('items.product');
        
        if (!cart || cart.items.length === 0) {
            return res.redirect('/cart');
        }

        res.render('checkout/index', {
            title: 'Checkout',
            cart: cart
        });
    } catch (error) {
        console.error('Error loading checkout:', error);
        res.status(500).send('Error loading checkout page');
    }
};

exports.placeOrder = async (req, res) => {
    try {
        const { name, phoneNumber, address } = req.body;
        const cart = await Cart.findOne({ user: req.session.user.id }).populate('items.product');

        if (!cart || cart.items.length === 0) {
            return res.redirect('/cart');
        }

        // Create order items from cart items
        const orderItems = cart.items.map(item => ({
            product: item.product._id,
            quantity: item.quantity,
            price: item.product.price
        }));

        // Create new order
        const order = new Order({
            user: req.session.user.id,
            items: orderItems,
            total: cart.total,
            shippingDetails: {
                name,
                phoneNumber,
                address
            },
            paymentMethod: 'cash'
        });

        await order.save();

        // Clear the cart
        await Cart.findByIdAndDelete(cart._id);

        // Redirect to order confirmation
        res.redirect(`/orders/${order._id}`);
    } catch (error) {
        console.error('Error placing order:', error);
        res.status(500).send('Error placing order');
    }
};