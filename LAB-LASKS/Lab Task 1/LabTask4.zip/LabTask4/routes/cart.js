const express = require('express');
const router = express.Router();
const cartController = require('../controllers/cartController');
const { isAuthenticated } = require('../middleware/auth');

// Apply authentication middleware to all cart routes
router.use(isAuthenticated);

// Cart view route
router.get('/', cartController.getCart);

// Add to cart
router.post('/add', cartController.addToCart);

// Update cart item
router.post('/update', cartController.updateCartItem);

// Remove from cart (with size)
router.get('/remove/:productId/:size', cartController.removeFromCart);

module.exports = router;