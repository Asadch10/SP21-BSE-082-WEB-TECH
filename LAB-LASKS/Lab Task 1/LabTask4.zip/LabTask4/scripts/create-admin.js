const mongoose = require('mongoose');
const User = require('../models/User');
require('dotenv').config();

async function createAdmin() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to MongoDB');

        // Create admin user
        const adminUser = new User({
            name: 'Admin User',
            email: 'ahmad.admin@gmail.com',
            password: '$2a$10$5Y5WipIP9qWkR0gL6MCV9uEY8EcMQe/gvuZhT3vGYYGITHPYrBA4e', // This is hash for '123'
            isAdmin: true
        });

        await adminUser.save();
        console.log('Admin user created successfully');
    } catch (error) {
        if (error.code === 11000) {
            // If user exists, update to make them admin
            const user = await User.findOneAndUpdate(
                { email: 'ahmad.admin@gmail.com' },
                { isAdmin: true },
                { new: true }
            );
            console.log('Existing user updated to admin');
        } else {
            console.error('Error:', error);
        }
    } finally {
        await mongoose.connection.close();
    }
}

createAdmin();
