const mongoose = require('mongoose');
const User = require('../models/User');
const bcrypt = require('bcryptjs');
require('dotenv').config();

async function updateAdminPassword() {
    try {
        await mongoose.connect(process.env.MONGODB_URI);
        console.log('Connected to MongoDB');

        // Hash the password
        const hashedPassword = await bcrypt.hash('123', 10);

        // Update or create admin user
        const adminUser = await User.findOneAndUpdate(
            { email: 'ahmad.admin@gmail.com' },
            {
                $set: {
                    name: 'Admin User',
                    password: hashedPassword,
                    isAdmin: true
                }
            },
            { upsert: true, new: true }
        );

        console.log('Admin user updated successfully');
        console.log('Email: ahmad.admin@gmail.com');
        console.log('Password: 123');
        console.log('isAdmin:', adminUser.isAdmin);

    } catch (error) {
        console.error('Error:', error);
    } finally {
        await mongoose.connection.close();
    }
}

updateAdminPassword();
