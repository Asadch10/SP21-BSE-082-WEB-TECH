const bcrypt = require('bcryptjs');

// Simple in-memory user storage (replace with database in production)
const users = [];

exports.getLogin = (req, res) => {
    res.render('auth/login', { 
        title: 'Login',
        layout: 'layouts/auth'
    });
};

exports.getRegister = (req, res) => {
    res.render('auth/register', { 
        title: 'Register',
        layout: 'layouts/auth'
    });
};

exports.getDashboard = (req, res) => {
    if (!req.session.user) {
        return res.redirect('/auth/login');
    }
    res.render('auth/dashboard', {
        title: 'Dashboard',
        user: req.session.user,
        layout: 'layouts/main'
    });
};

exports.postLogin = async (req, res) => {
    const { email, password } = req.body;
    
    try {
        const user = users.find(u => u.email === email);
        if (!user) {
            return res.render('auth/login', {
                title: 'Login',
                layout: 'layouts/auth',
                error: 'Invalid email or password'
            });
        }

        const validPassword = await bcrypt.compare(password, user.password);
        if (!validPassword) {
            return res.render('auth/login', {
                title: 'Login',
                layout: 'layouts/auth',
                error: 'Invalid email or password'
            });
        }

        // Set user session
        req.session.user = {
            id: user.id,
            name: user.name,
            email: user.email
        };

        res.redirect('/products');
    } catch (error) {
        console.error('Login error:', error);
        res.render('auth/login', {
            title: 'Login',
            layout: 'layouts/auth',
            error: 'An error occurred during login'
        });
    }
};

exports.postRegister = async (req, res) => {
    const { name, email, password, confirmPassword } = req.body;

    try {
        // Validate password match
        if (password !== confirmPassword) {
            return res.render('auth/register', {
                title: 'Register',
                layout: 'layouts/auth',
                error: 'Passwords do not match'
            });
        }

        // Check if user exists
        if (users.find(u => u.email === email)) {
            return res.render('auth/register', {
                title: 'Register',
                layout: 'layouts/auth',
                error: 'Email already registered'
            });
        }

        // Hash password
        const hashedPassword = await bcrypt.hash(password, 10);
        
        // Create new user
        const user = {
            id: users.length + 1,
            name,
            email,
            password: hashedPassword
        };

        users.push(user);

        res.redirect('/auth/login');
    } catch (error) {
        console.error('Registration error:', error);
        res.render('auth/register', {
            title: 'Register',
            layout: 'layouts/auth',
            error: 'An error occurred during registration'
        });
    }
};

exports.logout = (req, res) => {
    req.session.destroy((err) => {
        if (err) {
            console.error('Logout error:', err);
        }
        res.redirect('/auth/login');
    });
};