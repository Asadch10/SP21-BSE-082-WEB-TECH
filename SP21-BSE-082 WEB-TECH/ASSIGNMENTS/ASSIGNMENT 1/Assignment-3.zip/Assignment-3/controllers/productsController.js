// Sample product data (replace with database in production)
const products = [
    {
        id: 1,
        name: 'Wireless Headphones',
        price: 99.99,
        description: 'High-quality wireless headphones with noise cancellation',
        image: '/images/headphones.jpg'
    },
    {
        id: 2,
        name: 'Smart Watch',
        price: 199.99,
        description: 'Feature-rich smartwatch with health tracking',
        image: '/images/smartwatch.jpg'
    },
    {
        id: 3,
        name: 'Laptop Bag',
        price: 49.99,
        description: 'Stylish and durable laptop bag with multiple compartments',
        image: '/images/laptop-bag.jpg'
    }
];

exports.getAllProducts = (req, res) => {
    res.render('index', {
        title: 'Home',
        products: products
    });
};

exports.getProductById = (req, res) => {
    const product = products.find(p => p.id === parseInt(req.params.id));
    if (!product) {
        return res.status(404).send('Product not found');
    }
    res.render('product-detail', {
        title: product.name,
        product: product
    });
};