document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const menuIcon = document.querySelector('.menu-icon');
    const navList = document.querySelector('nav ul');

    menuIcon.addEventListener('click', function() {
        navList.classList.toggle('show');
    });

    // Close menu when clicking outside
    document.addEventListener('click', function(e) {
        if (!menuIcon.contains(e.target) && !navList.contains(e.target) && navList.classList.contains('show')) {
            navList.classList.remove('show');
        }
    });

    // Close menu when window is resized above mobile breakpoint
    window.addEventListener('resize', function() {
        if (window.innerWidth > 768 && navList.classList.contains('show')) {
            navList.classList.remove('show');
        }
    });
});