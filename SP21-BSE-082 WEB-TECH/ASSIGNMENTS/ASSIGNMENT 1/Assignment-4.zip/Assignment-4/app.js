const express = require('express');
const expressLayouts = require('express-ejs-layouts');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');
const connectDB = require('./config/database');
const authRoutes = require('./routes/auth');
const productsRoutes = require('./routes/products');
const cartRoutes = require('./routes/cart');
const checkoutRoutes = require('./routes/checkout');
const { isAuthenticated } = require('./middleware/auth');
const { cartCounter } = require('./middleware/cart');

// Connect to MongoDB
connectDB();

const app = express();

// Middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());
app.use(express.static('public'));

// Session configuration
app.use(session({
    secret: process.env.SESSION_SECRET || 'your-secret-key',
    resave: false,
    saveUninitialized: false,
    cookie: { 
        secure: false, // Set to true in production with HTTPS
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
    }
}));

// Make user data available to all templates
app.use((req, res, next) => {
    res.locals.user = req.session.user || null;
    res.locals.isAuthenticated = req.session.user != null;
    next();
});

// Cart counter middleware
app.use(cartCounter);

// EJS setup
app.use(expressLayouts);
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));
app.set('layout', 'layouts/main');

// Layout middleware - set auth layout for auth routes
app.use(['/auth', '/login', '/register'], (req, res, next) => {
    res.locals.layout = 'layouts/auth';
    next();
});

// Mount auth routes for both /auth and root paths
app.use(['/auth', '/'], authRoutes);

// Protected Routes
app.use('/products', isAuthenticated, productsRoutes);
app.use('/cart', isAuthenticated, cartRoutes);
app.use('/checkout', isAuthenticated, checkoutRoutes);

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});