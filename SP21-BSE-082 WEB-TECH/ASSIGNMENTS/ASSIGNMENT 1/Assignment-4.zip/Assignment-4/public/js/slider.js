document.addEventListener('DOMContentLoaded', function() {
    const slider = document.querySelector('.slider');
    const slides = document.querySelectorAll('.slide');
    const prevBtn = document.querySelector('.prev-btn');
    const nextBtn = document.querySelector('.next-btn');
    const dots = document.querySelectorAll('.slider-dot');
    
    let currentSlide = 0;
    const slideCount = slides.length;

    // Set initial position of slides
    function initializeSlides() {
        slides.forEach((slide, index) => {
            slide.style.transform = `translateX(${index * 100}%)`;
        });
    }

    // Move slides
    function moveSlides() {
        slides.forEach((slide, index) => {
            slide.style.transform = `translateX(${(index - currentSlide) * 100}%)`;
        });
    }

    // Initialize the slider
    initializeSlides();

    // Previous button click handler
    prevBtn.addEventListener('click', function(e) {
        e.preventDefault();
        currentSlide--;
        if (currentSlide < 0) {
            currentSlide = slideCount - 1;
        }
        moveSlides();
        updateDots();
    });

    // Next button click handler
    nextBtn.addEventListener('click', function(e) {
        e.preventDefault();
        currentSlide++;
        if (currentSlide > slideCount - 1) {
            currentSlide = 0;
        }
        moveSlides();
        updateDots();
    });

    // Update the dots
    function updateDots() {
        dots.forEach((dot, index) => {
            if (index === currentSlide) {
                dot.classList.add('active');
            } else {
                dot.classList.remove('active');
            }
        });
    }

    // Dot click handlers
    dots.forEach((dot, index) => {
        dot.addEventListener('click', () => {
            currentSlide = index;
            moveSlides();
            updateDots();
        });
    });

    // Auto slide functionality
    function autoSlide() {
        currentSlide++;
        if (currentSlide > slideCount - 1) {
            currentSlide = 0;
        }
        moveSlides();
        updateDots();
    }

    // Start auto sliding
    let slideInterval = setInterval(autoSlide, 5000);

    // Pause on hover
    slider.addEventListener('mouseenter', () => {
        clearInterval(slideInterval);
    });

    // Resume on mouse leave
    slider.addEventListener('mouseleave', () => {
        slideInterval = setInterval(autoSlide, 5000);
    });
});